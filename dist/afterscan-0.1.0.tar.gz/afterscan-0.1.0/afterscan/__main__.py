
from .afterscan import main
main()